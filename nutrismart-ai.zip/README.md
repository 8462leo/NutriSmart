# 🧠 NutriSmart AI

Gerador inteligente de planos alimentares com IA, feito em Next.js + Tailwind + Shadcn UI.

## 🚀 Rodar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:3000 no navegador.

## 🌐 Deploy

Conecte o repositório ao [Vercel](https://vercel.com/) e publique com 1 clique.
